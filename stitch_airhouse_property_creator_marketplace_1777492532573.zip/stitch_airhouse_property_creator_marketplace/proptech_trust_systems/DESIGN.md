---
name: PropTech Trust Systems
colors:
  surface: '#f9f9ff'
  surface-dim: '#d3daef'
  surface-bright: '#f9f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f1f3ff'
  surface-container: '#e9edff'
  surface-container-high: '#e1e8fd'
  surface-container-highest: '#dce2f7'
  on-surface: '#141b2b'
  on-surface-variant: '#404945'
  inverse-surface: '#293040'
  inverse-on-surface: '#edf0ff'
  outline: '#707975'
  outline-variant: '#c0c8c4'
  surface-tint: '#38675a'
  primary: '#38675a'
  on-primary: '#ffffff'
  primary-container: '#6b9b8c'
  on-primary-container: '#003127'
  inverse-primary: '#9fd1c0'
  secondary: '#006c4e'
  on-secondary: '#ffffff'
  secondary-container: '#80f9c8'
  on-secondary-container: '#007353'
  tertiary: '#555f6d'
  on-tertiary: '#ffffff'
  tertiary-container: '#8892a2'
  on-tertiary-container: '#212b38'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#bbeddc'
  primary-fixed-dim: '#9fd1c0'
  on-primary-fixed: '#002019'
  on-primary-fixed-variant: '#1e4f42'
  secondary-fixed: '#80f9c8'
  secondary-fixed-dim: '#62dcad'
  on-secondary-fixed: '#002115'
  on-secondary-fixed-variant: '#00513a'
  tertiary-fixed: '#d9e3f4'
  tertiary-fixed-dim: '#bdc7d8'
  on-tertiary-fixed: '#121c28'
  on-tertiary-fixed-variant: '#3e4755'
  background: '#f9f9ff'
  on-background: '#141b2b'
  surface-variant: '#dce2f7'
typography:
  headline-xl:
    fontFamily: Inter
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-lg:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.02em
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.04em
  data-mono:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  base: 8px
  xs: 4px
  sm: 12px
  md: 24px
  lg: 48px
  xl: 80px
  gutter: 24px
  margin: 32px
---

## Brand & Style

This design system is built upon a foundation of **Modern Corporate** aesthetics, specifically tailored for the property and finance intersection. The brand personality is authoritative yet accessible, designed to evoke a sense of institutional security while maintaining the speed and clarity of a high-growth technology platform.

The visual direction prioritizes data density and legibility over decorative elements. By utilizing a "High-Trust" aesthetic, the system employs ample whitespace, a disciplined color application, and a focus on structural alignment to reassure users navigating high-stakes financial decisions. The style is clean and technical, ensuring that property data and financial metrics remain the focal point of the user experience.

## Colors

The color palette is rooted in professional stability and growth. The **Primary** color (#6B9B8C) is a sophisticated, muted sage that bridges the gap between traditional banking and modern environmental property values. It is used for primary navigation and core brand elements.

The **Secondary** color (#6EE7B7) serves as the high-contrast engine for the design system. This vibrant mint is reserved exclusively for primary call-to-actions, success states, and critical conversion points to ensure they pop against the professional background.

**Neutrals** are led by a deep, trustworthy navy (#111827) for text and structural elements, providing the necessary weight to balance the lighter greens. Backgrounds are primarily white or extremely light gray to maintain a "clean" and "data-first" dashboard environment.

## Typography

This design system exclusively utilizes **Inter** to ensure maximum legibility across dense data tables and financial dashboards. The typographic hierarchy is strictly systematic, using weight and scale to differentiate between editorial content and functional data.

For dashboard environments, use the `label` and `data-mono` styles to present metrics. Headlines use tighter letter-spacing and heavier weights to provide an architectural feel to the page layout. Body text is optimized for readability with generous line heights to prevent user fatigue during long sessions of property analysis.

## Layout & Spacing

The layout follows a **Fixed Grid** philosophy for desktop experiences, ensuring that complex data visualizations maintain their integrity across standard professional monitors. A 12-column grid is used for the main content area, with a maximum container width of 1280px.

A strict 8px base unit governs all spacing decisions. This creates a rhythmic "data-grid" feel that aligns with the professional nature of the industry. Internal padding for cards and data modules should lean towards the `md` (24px) unit to allow the "clean" aesthetic to breathe, while compact data views may utilize the `sm` (12px) unit for increased density.

## Elevation & Depth

To maintain the "sharp" and "modern" requirement, the design system utilizes **low-contrast outlines** combined with **tonal layers** rather than heavy shadows. Depth is primarily established by stacking surfaces of slightly different neutral values.

When elevation is necessary (e.g., for active modals or hovering state on property cards), use an **ambient shadow**: a subtle, extra-diffused shadow with very low opacity (e.g., 4-8%) and a slight tint of the primary neutral color (#111827). This keeps the interface feeling grounded and physical without sacrificing the clean, flat aesthetic. Dividers should be 1px solid lines using a light gray tint to separate data sets with surgical precision.

## Shapes

The shape language for this design system is **Soft**, leaning toward the sharper side of modern UI. A 4px (0.25rem) base radius is applied to standard components like buttons and input fields to prevent them from feeling aggressive while maintaining a professional, structured silhouette.

Property cards and main dashboard containers use the same 4px radius, creating a consistent "box" feel that reflects architectural blueprints. For larger containers or "hero" elements, the `rounded-lg` (8px) variant may be used, but the overall intent is to avoid the overly-circular trends of social apps in favor of the precise, rectangular logic of the property sector.

## Components

### Buttons
Primary action buttons utilize the Secondary Mint (#6EE7B7) with deep navy text for maximum contrast. They are rectangular with the standard 4px radius. Secondary buttons use the Primary Sage (#6B9B8C) or a Ghost style with a 1px border.

### Cards
Cards are the primary vehicle for property listings and data modules. They feature a 1px border (#E5E7EB) and no default shadow. The design is "sharp," focusing on internal margin consistency and clear typography hierarchy. Content inside cards is strictly aligned to a sub-grid.

### Form Elements
Inputs use a "high-trust" design: 1px solid borders that darken on focus to the Primary Sage. Labels are always visible above the field in `label-md` weight. Error states are clearly defined with a sharp red border and descriptive text.

### Data Visualizations
Charts and graphs should exclusively use the brand palette (Sage, Mint, Gray). Line charts use thick, 2px paths for clarity. Tooltips are dark (#111827) with high-contrast white text to ensure they stand out over complex data points.

### Chips & Tags
Used for property status (e.g., "For Sale," "Managed"). These are small, non-rounded rectangles with a light background tint of the status color and a darker text variant to maintain professional legibility.
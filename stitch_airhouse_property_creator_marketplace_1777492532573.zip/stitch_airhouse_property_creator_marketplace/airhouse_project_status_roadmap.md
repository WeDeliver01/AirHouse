# AirHouse Design Roadmap & Status

This document tracks the design progress for AirHouse, a full-stack prop-tech marketplace connecting developers and creators in South Africa.

## ✅ Completed Modules

### 1. Onboarding & Foundation
- **Developer Onboarding:** 3-step wizard (Company -> Specialties -> Goals).
- **Creator Onboarding:** 3-step wizard (Profile -> Skills -> Rates).
- **Design System:** "PropTech Trust Systems" (Institutional-grade UI).

### 2. Developer Experience
- **Campaign Manager:** Briefing and budget settings.
- **Sales Pipeline:** Kanban-style lead tracking.
- **Messaging:** Contextual chat for collaboration.
- **Notifications:** Actionable alerts panel.

### 3. Creator Experience
- **Creator Dashboard:** Overview of performance and active links.
- **Public Profile:** Shareable portfolio and stats.
- **Performance Scorecard:** Refined data-driven metrics and tier tracking.
- **Payouts:** ZAR earnings management and withdrawal requests.
- **Verification Flow:** Multi-level (ID upload, Social Proof).

### 4. Super Admin Experience
- **Admin Dashboard:** Platform-wide financial and operational oversight.
- **Verification Review:** Interface for approving creator documents.
- **Admin Analytics:** Macro-level performance and market intelligence.

### 5. Shared / Support
- **Digital Contracts:** Legal agreement signing view.
- **Help Center:** Self-service resources and support pathways.

---

## 🚀 Missing / Next Steps

### High Priority
- **Dispute Resolution System:**
    - Developer/Creator reporting interface.
    - Admin mediation workspace.
- **Creator Marketplace (Browse):**
    - Search and filter interface for developers to find talent.
- **Property Management:**
    - CRUD interface for property listings (title, price, location, photos).

### Medium Priority
- **Transaction History & Invoicing:**
    - Detailed logs of ZAR movements.
    - Downloadable PDF invoices with 25% fee breakdown.
- **Campaign Assignments Flow:**
    - "Invite to Campaign" workflow.
    - Assignment acceptance/rejection screens.

### Polish & Nuance
- **Digital Badges Gallery:** Expanded view of earned achievements.
- **Interactive Lead Detail:** Deep-dive view of a single lead's journey.
